#!/usr/bin/env python3
import json, os
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
H = os.path.dirname(os.path.abspath(__file__)); R = os.path.join(H, 'results'); D = os.path.join(H, 'docs')
os.makedirs(D, exist_ok=True)
BLUE, ORANGE, AQUA, GRAY, YEL = '#2a78d6', '#eb6834', '#1baf7a', '#8a8a85', '#eda100'
plt.rcParams.update({'font.size': 9.5, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.grid': True,
                     'grid.color': '#e6e6e3', 'axes.axisbelow': True, 'axes.edgecolor': '#b5b5b0',
                     'axes.titleweight': 'bold'})
J = lambda n: json.load(open(os.path.join(R, n + '.json'))) if os.path.exists(os.path.join(R, n + '.json')) else None
ctrl = J('control')
mili = lambda r: 1e3 * r['vs_control']['delta']
err = lambda r: [[1e3 * (r['vs_control']['delta'] - r['vs_control']['ci95'][0])], [1e3 * (r['vs_control']['ci95'][1] - r['vs_control']['delta'])]]


def save(f, n):
    f.tight_layout(); f.savefig(os.path.join(D, n), dpi=150); plt.close(f)


mg, nm = J('magnitude'), J('nm')
if mg:
    f, ax = plt.subplots(figsize=(6.6, 3.6))
    for key, col, lab in (('one_shot', GRAY, 'one-shot, no fine-tune'), ('one_shot_ft', BLUE, 'one-shot + fine-tune'),
                          ('gradual_ft', AQUA, 'gradual (cubic) + fine-tune')):
        xs = [100 * r['sparsity'] for r in mg]
        ax.errorbar(xs, [mili(r[key]) for r in mg], yerr=[sum(e, []) for e in zip(*[err(r[key]) for r in mg])],
                    fmt='-o', color=col, ms=4, lw=1.8, capsize=2, label=lab)
    if nm:
        for r, mk in zip(nm, ('s', 'D')):
            ax.errorbar(100 * r['ft']['linear_sparsity'], mili(r['ft']), yerr=err(r['ft']), fmt=mk, color=ORANGE,
                        ms=6, capsize=2, label=f"{r['pattern']} structured + fine-tune")
    ax.axhline(0, color='#b5b5b0', lw=1); ax.set_yscale('symlog', linthresh=10)
    ax.set_xlabel('linear-weight sparsity (%)'); ax.set_ylabel('Δ loss vs dense control (milli-nats/char)')
    ax.set_title('Weight pruning (no accelerator speedup: weights run off-chip)'); ax.legend(frameon=False, fontsize=8)
    save(f, 'weight_pruning.png')

hd = J('heads')
if hd:
    f, ax = plt.subplots(figsize=(6.6, 3.6))
    base_cyc = ctrl['attn_cycles']
    imp = [r for r in hd['runs'] if not r.get('random')]; rnd = [r for r in hd['runs'] if r.get('random')]
    for key, col, lab in (('one_shot', GRAY, 'importance, one-shot'), ('ft', BLUE, 'importance + fine-tune')):
        ax.errorbar([100 * r[key]['attn_cycles'] / base_cyc for r in imp], [mili(r[key]) for r in imp],
                    yerr=[sum(e, []) for e in zip(*[err(r[key]) for r in imp])], fmt='-o', color=col, ms=4, capsize=2, label=lab)
    ax.errorbar([100 * r['ft']['attn_cycles'] / base_cyc for r in rnd], [mili(r['ft']) for r in rnd],
                yerr=[sum(e, []) for e in zip(*[err(r['ft']) for r in rnd])], fmt='x', color=ORANGE, ms=7, capsize=2,
                label='random heads + fine-tune')
    for r in imp:
        ax.annotate(f"-{r['pruned']}", (100 * r['ft']['attn_cycles'] / base_cyc, mili(r['ft'])), textcoords='offset points',
                    xytext=(4, -9), fontsize=7)
    ax.axhline(0, color='#b5b5b0', lw=1); ax.set_yscale('symlog', linthresh=10)
    ax.set_xlabel('accelerator attention cycles (% of dense)'); ax.set_ylabel('Δ loss vs dense control (milli-nats/char)')
    ax.set_title('Head pruning (of 32 heads): loss vs RTL cycles'); ax.legend(frameon=False, fontsize=8)
    save(f, 'head_pruning.png')

wd = J('window')
if wd:
    f, ax = plt.subplots(figsize=(6.6, 3.6))
    for key, col, lab in (('zero_shot', GRAY, 'window, no fine-tune'), ('ft', BLUE, 'window + fine-tune')):
        ax.errorbar([100 * r[key]['attn_cycles'] / ctrl['attn_cycles'] for r in wd], [mili(r[key]) for r in wd],
                    yerr=[sum(e, []) for e in zip(*[err(r[key]) for r in wd])], fmt='-o', color=col, ms=4, capsize=2, label=lab)
    for r in wd:
        ax.annotate(f"{r['window_tokens']} tok", (100 * r['ft']['attn_cycles'] / ctrl['attn_cycles'], mili(r['ft'])),
                    textcoords='offset points', xytext=(4, 4), fontsize=7)
    ax.axhline(0, color='#b5b5b0', lw=1); ax.set_yscale('symlog', linthresh=10)
    ax.set_xlabel('accelerator attention cycles (% of full causal)'); ax.set_ylabel('Δ loss vs dense control (milli-nats/char)')
    ax.set_title('Block-local attention (RTL tile window)'); ax.legend(frameon=False, fontsize=8)
    save(f, 'window.png')

q = J('quant')
if q:
    f, ax = plt.subplots(figsize=(6.6, 3.4))
    lab = lambda r: f"INT{r['bits']}" + (f"/g{r['group']}" if r['group'] else '/ch')
    xs = [lab(r) for r in q['ptq']]
    ax.bar([i - 0.2 for i in range(len(xs))], [mili(r) for r in q['ptq']], 0.38, color=GRAY, label='post-training (PTQ)')
    qm = {lab(r): r for r in q['qat']}
    ax.bar([i + 0.2 for i, x in enumerate(xs) if x in qm], [mili(qm[x]) for x in xs if x in qm], 0.38, color=BLUE,
           label='quantization-aware (QAT)')
    ax.set_xticks(range(len(xs)), xs); ax.set_yscale('symlog', linthresh=10); ax.axhline(0, color='#b5b5b0', lw=1)
    ax.set_ylabel('Δ loss vs dense control (milli-nats/char)'); ax.set_title('Weight quantization (per-channel / group-16)')
    ax.legend(frameon=False, fontsize=8)
    save(f, 'quantization.png')
print('compress plots ->', D)

if hd and wd:
    f, ax = plt.subplots(figsize=(6.6, 3.6)); bc = ctrl['attn_cycles']
    imp = [r for r in hd['runs'] if not r.get('random')]
    ax.errorbar([100 * r['ft']['attn_cycles'] / bc for r in imp], [mili(r['ft']) for r in imp],
                yerr=[sum(e, []) for e in zip(*[err(r['ft']) for r in imp])], fmt='-o', color=ORANGE, ms=4, capsize=2,
                label='head pruning + fine-tune')
    ws = [r for r in wd if r['window_tiles'] > 1]
    ax.errorbar([100 * r['ft']['attn_cycles'] / bc for r in ws], [mili(r['ft']) for r in ws],
                yerr=[sum(e, []) for e in zip(*[err(r['ft']) for r in ws])], fmt='-o', color=BLUE, ms=4, capsize=2,
                label='block-local window + fine-tune')
    cb = J('combined')
    if cb:
        for r in cb:
            if r['plan'].startswith('informed'):
                ax.plot(100 * r['attn_cycles'] / bc, mili(r), '*', color=AQUA, ms=10)
        ax.plot([], [], '*', color=AQUA, ms=10, label='informed stack (+ INT4/g16 weights)')
    ax.set_yscale('log'); ax.set_xlabel('accelerator attention cycles (% of dense causal)')
    ax.set_ylabel('Δ loss vs dense control (milli-nats/char)')
    ax.set_title('Same cycle budget, very different cost'); ax.legend(frameon=False, fontsize=8)
    save(f, 'cycles_tradeoff.png')
